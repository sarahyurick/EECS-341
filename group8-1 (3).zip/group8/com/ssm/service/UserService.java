package com.ssm.service;

import com.ssm.dao.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.entity.User;
import com.ssm.service.ex.NotNullException;

import java.util.List;

@Service
public class UserService
{

    @Autowired
    private UserMapper userdao;

    public User login(String username, String password)
    {
        if (username == null || username.equals("")
                || password == null || password.equals(""))
        {
            return null;
        }
        User user = userdao.findbyname(username);
        if (user != null && user.getPassword().equals(password))
        {
            return user;
        }
        else
        {
            return null;
        }
    }

    public void register(User user)
    {
        System.out.println(user);
        int i = userdao.register(user);
    }

    public User findbyname(String username)
    {
        return userdao.findbyname(username);
    }

    public void userupdate(User user)
    {
        userdao.userupdate(user);
    }

    public List<User> findseller()
    {
        return userdao.findseller();
    }
}
