package com.ssm.service;

import com.ssm.dao.OrderMapper;
import com.ssm.entity.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrderService {
    @Autowired
    private OrderMapper orderdao;

    public void save(Order order) {
        orderdao.save(order);
    }

    public List<Order> findbyb_name(String b_name) {
        return orderdao.findbyb_name(b_name);
    }

    public List<Order> findbys_name(String s_name) {
        return orderdao.findbys_name(s_name);
    }

}
