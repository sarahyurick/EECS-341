package com.ssm.service;

import com.ssm.dao.ItemsMapper;
import com.ssm.entity.Item;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class ItemsService {
    @Autowired
    private ItemsMapper itemsdao;

    public List<Item> findbys_name(String s_name) {
        return itemsdao.findbys_name(s_name);
    }

    public void save(Item item) {
        itemsdao.save(item);
    }

    public void deleteitemsbyid(Integer itemsid) {
        itemsdao.deleteitemsbyid(itemsid);
    }

    public Item findbyid(Integer id) {
        return itemsdao.findbyid(id);
    }

    public void update(Item item) {
        itemsdao.update(item);
    }

    public List<Item> findbyitemsname(String itemsname) {
        return itemsdao.findbyitemsname(itemsname);
    }

    public List<Item> findbymyitemsname(String itemsname, String username) {
        return itemsdao.findbymyitemsname(itemsname, username);
    }
}