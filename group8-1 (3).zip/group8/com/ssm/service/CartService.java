package com.ssm.service;

import com.ssm.dao.CartMapper;
import com.ssm.entity.Cart;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CartService {
    @Autowired
    private CartMapper cartdao;

    public void save(Cart cart) {
        cartdao.save(cart);
    }

    public List<Cart> findbyb_name(String b_name) {
        return cartdao.findbyb_name(b_name);
    }

    public Cart findby(Integer i_id, String b_name) {
        return cartdao.findby(i_id, b_name);
    }

    public Cart findbyid(Integer cartid) {
        return cartdao.findbyid(cartid);
    }

    public void update(Cart cart) {
        cartdao.update(cart);
    }

    public void delcartbyid(Integer cartid) {
        cartdao.delcartbyid(cartid);
    }
}
