package com.ssm.entity;

import java.io.Serializable;

public class Cart implements Serializable {
    private Integer id;
    private Integer amount;
    private Integer price;
    private String b_name;
    private String s_name;
    private String item_name;
    private Integer item_id;

    public Cart() {
    }

    public Cart(Integer id, Integer item_id, Integer amount, String b_name, Integer price, String s_name,
            String item_name) {
        this.id = id;
        this.amount = amount;
        this.price = price;
        this.b_name = b_name;
        this.s_name = s_name;
        this.item_name = item_name;
        this.item_id = item_id;
    }

    @Override
    public String toString() {
        return "Cart{" + "id=" + id + ", amount=" + amount + ", price=" + price + ", b_name='" + b_name + '\''
                + ", s_name='" + s_name + '\'' + ", item_name='" + item_name + '\'' + ", item_id=" + item_id + '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getB_name() {
        return b_name;
    }

    public void setB_name(String b_name) {
        this.b_name = b_name;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public String getItem_name() {
        return item_name;
    }

    public void setItem_name(String item_name) {
        this.item_name = item_name;
    }

    public Integer getItem_id() {
        return this.item_id;
    }

    public void setItem_id(Integer item_id) {
        this.item_id = item_id;
    }
}
