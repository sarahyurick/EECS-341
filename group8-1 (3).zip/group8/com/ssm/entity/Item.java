package com.ssm.entity;

import java.io.Serializable;

public class Item implements Serializable {
    private Integer id;
    private String itemsname;
    private Integer price;
    private String describ;
    private String baker_name;

    public Item(Integer id, String itemsname, Integer price, String describ, String baker_name) {
        this.id = id;
        this.itemsname = itemsname;
        this.price = price;
        this.describ = describ;
        this.baker_name = baker_name;
    }

    @Override
    public String toString() {
        return "Items{" + "id=" + id + ", item name='" + itemsname + '\'' + ", price=" + price + ", describtion ='"
                + describ + '\'' + ", baker_name='" + baker_name + '\'' + '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getItemsname() {
        return itemsname;
    }

    public void setItemsname(String itemsname) {
        this.itemsname = itemsname;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getDescrib() {
        return describ;
    }

    public void setDescrib(String describ) {
        this.describ = describ;
    }

    public String getBaker_name() {
        return baker_name;
    }

    public void setBaker_name(String baker_name) {
        this.baker_name = baker_name;
    }
}