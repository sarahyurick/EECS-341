package com.ssm.entity;

import java.io.Serializable;

public class Order implements Serializable {
    private Integer id;
    private Integer amount;
    private Integer price;
    private String buyername;
    private String s_name;
    private String item_name;
    private Integer item_id;
    private Integer phone;
    private String address;

    public Order() {
    }

    @Override

    public String toString() {
        return "Order{" + "id=" + id + ", amount=" + amount + ", price=" + price + ", b_name='" + buyername + '\''
                + ", s_name='" + s_name + '\'' + ", item_name='" + item_name + '\'' + ", item_id=" + item_id
                + ", phone=" + phone + ", address='" + address + '\'' + '}';
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        this.amount = amount;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public String getBuyername() {
        return buyername;
    }

    public void setBuyername(String b_name) {
        this.buyername = b_name;
    }

    public String getS_name() {
        return s_name;
    }

    public void setS_name(String s_name) {
        this.s_name = s_name;
    }

    public void setItem_name(String Item_name) {
        this.item_name = Item_name;
    }

    public String getItem_name() {
        return this.item_name;
    }

    public Integer getItem_id() {
        return item_id;
    }

    public void setItem_id(Integer item_id) {
        this.item_id = item_id;

    }

    public Integer getPhone() {
        return phone;
    }

    public void setPhone(Integer phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Order(Integer id, Integer amount, Integer price, String buyername, String s_name, String item_name,
            Integer item_id, Integer phone, String address) {
        this.id = id;
        this.amount = amount;
        this.price = price;
        this.buyername = buyername;
        this.s_name = s_name;
        this.item_name = item_name;
        this.item_id = item_id;
        this.phone = phone;
        this.address = address;

    }
}
