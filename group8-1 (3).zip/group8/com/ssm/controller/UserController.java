package com.ssm.controller;

import javax.servlet.http.HttpSession;

import com.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import com.ssm.entity.User;

@Controller
public class UserController {
    @Autowired
    private UserService userservice;

    @RequestMapping("/login.do")
    public String login(String username, String password, HttpSession session, Model model) {
        User user = userservice.login(username, password);
        if (user != null) {
            session.setAttribute("user", user);
            if (user.getFlag() == 1) {
                return "redirect:buy_home.do";
            } else if (user.getFlag() == 2) {
                return "redirect:sender_home.do";
            } else {
                return "redirect:sell_home.do";
            }
        } else {
            model.addAttribute("login_failed", "Wrong User Name or Password");
            return "login.jsp";
        }
    }

    @RequestMapping("/register.do")
    public String register(String username, String password, String phone, Model model, String flag, String address) {
        System.out.println(username);
        System.out.println(password);
        System.out.println(phone);
        System.out.println(flag);
        System.out.println(address);
        if (username == null || username.equals("") || password == null || password.equals("") || phone == null
                || phone.equals("") || address == null || address.equals("") || flag == null || flag.equals("")) {
            model.addAttribute("add_failed", "Login Information not Completed");
            return "register.jsp";
        } else {
            User user = userservice.findbyname(username);
            if (user == null) {
                if (flag.equals("0")) {
                    user = new User(null, username, password, Integer.valueOf(phone), Integer.valueOf(flag), address);
                } else {
                    user = new User(null, username, password, Integer.valueOf(phone), Integer.valueOf(flag), address);
                }
                userservice.register(user);
                return "login.jsp";
            }
            model.addAttribute("add_failed", "duplicated user name");
            return "register.jsp";
        }
    }

    @RequestMapping("/show_info.do")
    public String show_info() {
        return "show_info.jsp";
    }

    @RequestMapping("/sellershow_info.do")
    public String sellershow_info(HttpSession session, Model model) {
        return "sellershow_info.jsp";
    }

    @RequestMapping("/update.do")
    public String update(String username, String password, String phone, Model model, HttpSession session,
            String address) {
        User userget = (User) session.getAttribute("user");
        Integer flag = userget.getFlag();
        User user = new User(userget.getId(), username, password, Integer.valueOf(phone), flag, address);
        userservice.userupdate(user);
        session.setAttribute("user", user);
        return "redirect:show_info.do";
    }

    @RequestMapping("/sellerupdate.do")
    public String sellerupdate(String username, String password, String phone, Model model, HttpSession session,
            String address) {
        User userget = (User) session.getAttribute("user");
        Integer flag = userget.getFlag();
        User user = new User(userget.getId(), username, password, Integer.valueOf(phone), flag, address);
        userservice.userupdate(user);
        session.setAttribute("user", user);
        return "redirect:sellershow_info.do";
    }
}