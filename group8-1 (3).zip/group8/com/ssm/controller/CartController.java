package com.ssm.controller;

import com.ssm.entity.Cart;
import com.ssm.entity.Item;
import com.ssm.entity.Order;
import com.ssm.entity.User;
import com.ssm.service.CartService;
import com.ssm.service.ItemsService;
import com.ssm.service.OrderService;
import com.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.Iterator;
import java.util.List;

@Controller
public class CartController {
    @Autowired
    private CartService cartservice;
    @Autowired
    private ItemsService c_itemsservice;
    @Autowired
    private OrderService c_order_buyservice;
    @Autowired
    private UserService c_userservice;

    @RequestMapping("/addcart.do")
    public String addcart(Integer itemsid, HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        Item items = c_itemsservice.findbyid(itemsid);
        Cart cart = cartservice.findby(itemsid, user.getUsername());

        if (cart != null) {
            cart.setAmount(cart.getAmount() + 1);
            cartservice.update(cart);
        } else {
            cart = new Cart(null, itemsid, 1, user.getUsername(), items.getPrice(), items.getBaker_name(),
                    items.getItemsname());
            cartservice.save(cart);
        }

        return "redirect:buy_list.do?s_name=" + items.getBaker_name();
    }

    @RequestMapping("/addamount.do")
    public String addamount(Integer cartid, Model model) {
        Cart cart = cartservice.findbyid(cartid);
        cart.setAmount(cart.getAmount() + 1);
        cartservice.update(cart);
        return "redirect:cartlist.do";
    }

    @RequestMapping("/subamount.do")
    public String subamount(Integer cartid, Model model) {
        Cart cart = cartservice.findbyid(cartid);
        if (cart.getAmount() == 1) {
            return "redirect:cartlist.do";
        } else {
            cart.setAmount(cart.getAmount() - 1);
            cartservice.update(cart);
            return "redirect:cartlist.do";
        }

    }

    @RequestMapping("/cartlist.do")
    public String addcart(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        List<Cart> carts = cartservice.findbyb_name(user.getUsername());
        model.addAttribute("carts", carts);
        return "cartlist.jsp";
    }

    @RequestMapping("/delcart.do")
    public String delcart(Integer cartid, Model model) {
        cartservice.delcartbyid(cartid);
        return "cartlist.do";
    }

    @RequestMapping("/count.do")
    public String count(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        List<Cart> carts = cartservice.findbyb_name(user.getUsername());
        for (Iterator<Cart> cartIterator = carts.iterator(); cartIterator.hasNext();) {
            Cart cart = (Cart) cartIterator.next();
            Item items = c_itemsservice.findbyid(cart.getItem_id());
            User seller = c_userservice.findbyname(items.getBaker_name());
            Order order = new Order(null, cart.getAmount(), items.getPrice(), user.getUsername(), items.getBaker_name(),
                    items.getItemsname(), items.getId(), user.getPhone(), user.getAddress());
            cartservice.delcartbyid(cart.getId());
            c_order_buyservice.save(order);
        }
        return "cartlist.do";
    }
}
