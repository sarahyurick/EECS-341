package com.ssm.controller;

import com.ssm.entity.Item;
import com.ssm.entity.User;
import com.ssm.service.ItemsService;
import com.ssm.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import javax.servlet.http.HttpSession;
import java.util.*;

@Controller
public class ItemsController {
    @Autowired
    private ItemsService itemsservice;
    @Autowired
    private UserService item_userservice;

    @RequestMapping("/buy_home.do")
    public String buy_home(Model model) {
        List<User> sellers = item_userservice.findseller();
        model.addAttribute("sellers", sellers);
        return "buy_home.jsp";
    }

    @RequestMapping("/sell_home.do")
    public String sell_list(HttpSession session, Model model) {
        User Baker = (User) session.getAttribute("user");
        List<Item> myitems = itemsservice.findbys_name(Baker.getUsername());
        model.addAttribute("myitems", myitems);
        return "sell_home.jsp";
    }

    @RequestMapping("/buy_list.do")
    public String buy_list(HttpSession session, Model model) {
        User Baker = (User) session.getAttribute("user");
        List<Item> allitems = itemsservice.findbys_name("sean");
        model.addAttribute("allitems", allitems);
        return "buy_list.jsp";
    }

    @RequestMapping("/additems.do")
    public String additems(HttpSession session, String itemsname, String describ, String price) {
        User user = (User) session.getAttribute("user");
        String s_name = user.getUsername();
        Item items = new Item(null, itemsname, Integer.parseInt(price), describ, s_name);

        itemsservice.save(items);
        return "sell_home.do";
    }

    @RequestMapping("/del_items.do")
    public String delitems(Integer itemsid, Model model) {
        itemsservice.deleteitemsbyid(itemsid);
        return "sell_home.do";
    }

    @RequestMapping("/items_info.do")
    public String items_info(Integer itemsid, Model model) {
        Item item = itemsservice.findbyid(itemsid);
        model.addAttribute("items_info", item);
        return "update_items.jsp";
    }

    @RequestMapping("/update_items.do")
    public String items_info(Integer itemsid, String itemsname, String describ, String price, Model model,
            HttpSession session) {
        User user = (User) session.getAttribute("user");
        Item item = new Item(itemsid, itemsname, Integer.parseInt(price), describ, user.getUsername());
        itemsservice.update(item);
        model.addAttribute("items_info", item);
        return "update_items.jsp";
    }

    @RequestMapping("/search.do")
    public String search(HttpSession session, String itemsname, Model model) {
        User user = (User) session.getAttribute("user");
        if (user.getFlag() == 1) {
            List<Item> everything = itemsservice.findbyitemsname(itemsname);
            model.addAttribute("allitems", everything);
            return "buy_list.jsp";
        } else {
            String username = user.getUsername();
            List<Item> myitems = itemsservice.findbymyitemsname(itemsname, username);
            model.addAttribute("myitems", myitems);
            return "sell_home.jsp";
        }
    }

    @RequestMapping("/searchid.do")
    public String search(Integer item_id, Model model) {
        List<Item> allItems = new ArrayList<Item>();
        Item item = itemsservice.findbyid(item_id);
        allItems.add(item);
        model.addAttribute("allitems", allItems);
        return "buy_list.jsp";
    }
}
