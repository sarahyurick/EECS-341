package com.ssm.controller;

import com.ssm.entity.Order;
import com.ssm.entity.User;
import com.ssm.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
public class OrderController {
    // @Autowired
    // private Order_sellService order_sellservice;
    @Autowired
    private OrderService orderservice;

    @RequestMapping("/buyerorder.do")
    public String buyerorder(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        List<Order> orders = orderservice.findbyb_name(user.getUsername());
        model.addAttribute("buyerorders", orders);
        return "buyorder.jsp";
    }

    @RequestMapping("/sellerorder.do")
    public String sellerorder(HttpSession session, Model model) {
        User user = (User) session.getAttribute("user");
        List<Order> orders = orderservice.findbys_name(user.getUsername());
        model.addAttribute("sellerorders", orders);
        return "sellerorder.jsp";
    }

    @RequestMapping("/ready.do")
    public String ready(HttpSession session, Integer orderid, Model model) {
        User user = (User) session.getAttribute("user");
        List<Order> orders = orderservice.findbys_name(user.getUsername());
        model.addAttribute("sellerorders", orders);
        return "sellerorder.jsp";
    }

    @RequestMapping("/confirm.do")
    public String confirm(HttpSession session, Integer orderid, Model model) {
        User user = (User) session.getAttribute("user");
        List<Order> orders = orderservice.findbyb_name(user.getUsername());
        model.addAttribute("buyerorders", orders);
        return "buyorder.jsp";
    }
}
