package com.ssm.dao;

import com.ssm.entity.Order;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface OrderMapper {
    void save(Order order);

    List<Order> findbyb_name(String b_name);

    List<Order> findbys_name(String s_name);

}
