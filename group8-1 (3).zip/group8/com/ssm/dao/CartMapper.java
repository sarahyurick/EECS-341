package com.ssm.dao;

import com.ssm.entity.Cart;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CartMapper {
    Integer save(Cart cart);

    List<Cart> findbyb_name(String b_name);

    Cart findby(@Param("item_id") Integer i_id, @Param("b_name") String b_name);

    Cart findbyid(Integer cartid);

    void update(Cart cart);

    void delcartbyid(Integer cartid);
}
