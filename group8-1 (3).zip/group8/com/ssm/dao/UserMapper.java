package com.ssm.dao;

import com.ssm.entity.User;

import java.util.List;

public interface UserMapper
{

    public User findbyname(String username);

    public Integer register(User user);


    void userupdate(User user);

    List<User> findseller();
}