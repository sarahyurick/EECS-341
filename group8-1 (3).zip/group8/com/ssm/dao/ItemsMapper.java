package com.ssm.dao;

import com.ssm.entity.Item;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface ItemsMapper {
    List<Item> findbys_name(String s_name);

    void save(Item item);

    void deleteitemsbyid(Integer itemsid);

    Item findbyid(Integer itemsid);

    void update(Item item);

    List<Item> findbyitemsname(String itemsname);

    List<Item> findbymyitemsname(@Param("itemsname") String itemsname, @Param("username") String username);
}